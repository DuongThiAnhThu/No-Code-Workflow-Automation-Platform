import { createBrowserRouter } from 'react-router';
import HomePage from './pages/HomePage';
import WorkflowBuilderPage from './pages/WorkflowBuilderPage';
import LoginPage from './pages/LoginPage';
import AuditLogPage from './pages/AuditLogPage';
import TemplatesPage from './pages/TemplatesPage';
import { ProtectedRoute } from './components/ProtectedRoute';

export const router = createBrowserRouter([
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/',
    element: (
      <ProtectedRoute>
        <HomePage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/builder',
    element: (
      <ProtectedRoute>
        <WorkflowBuilderPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/audit-log',
    element: (
      <ProtectedRoute>
        <AuditLogPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/templates',
    element: (
      <ProtectedRoute>
        <TemplatesPage />
      </ProtectedRoute>
    ),
  },
]);