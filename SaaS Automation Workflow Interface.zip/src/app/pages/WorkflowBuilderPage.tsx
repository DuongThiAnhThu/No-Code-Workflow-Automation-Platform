import { Header } from '../components/Header';
import { Sidebar } from '../components/Sidebar';
import { CopilotPanel } from '../components/CopilotPanel';
import { WorkflowCanvas } from '../components/WorkflowCanvas';
import { RightPanel } from '../components/RightPanel';
import { TestRunResultsPanel } from '../components/TestRunResultsPanel';
import { PublishModal } from '../components/PublishModal';
import { useState } from 'react';
import { useNavigate } from 'react-router';

export type PanelType = 
  | 'linked-assets'
  | 'recent-demos'
  | 'details'
  | 'notes'
  | 'change-history'
  | 'demo-runs'
  | 'status'
  | 'advanced-settings'
  | 'versions'
  | null;

export default function WorkflowBuilderPage() {
  const [activePanel, setActivePanel] = useState<PanelType>(null);
  const [emailTriggerConfigOpen, setEmailTriggerConfigOpen] = useState(false);
  const [testRunResultsOpen, setTestRunResultsOpen] = useState(false);
  const [publishModalOpen, setPublishModalOpen] = useState(false);
  const [isPublished, setIsPublished] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const navigate = useNavigate();

  const handlePanelToggle = (panel: PanelType) => {
    setActivePanel(activePanel === panel ? null : panel);
  };

  const handleEmailTriggerSelect = () => {
    setActivePanel(null);
    setEmailTriggerConfigOpen(true);
  };

  const handleTestRun = async () => {
    setIsRunning(true);
    setActivePanel(null);
    
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    setIsRunning(false);
    setTestRunResultsOpen(true);
  };

  const handleRunAgain = () => {
    setTestRunResultsOpen(false);
    handleTestRun();
  };

  const handlePublishClick = () => {
    setPublishModalOpen(true);
  };

  const handlePublish = () => {
    setIsPublished(true);
    
    // Save new workflow to localStorage
    const newWorkflow = {
      id: Date.now().toString(),
      name: 'Untitled Workflow',
      status: 'active' as const,
      trigger: 'Email',
      lastRun: 'Just now',
      successRate: '100%',
      updated: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      isNew: true,
    };
    
    localStorage.setItem('newWorkflow', JSON.stringify(newWorkflow));
  };

  const handleNavigateToHome = () => {
    navigate('/');
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Header 
        onTestRun={handleTestRun}
        onPublish={handlePublishClick}
        isPublished={isPublished}
        isRunning={isRunning}
      />

      {showSuccessToast && (
        <div className="fixed top-20 right-6 z-50 animate-slide-in-right">
          <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-4 flex items-center gap-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Demo is now live</p>
              <p className="text-xs text-gray-500">Your workflow is published and running</p>
            </div>
          </div>
        </div>
      )}

      <div className="flex h-[calc(100vh-64px)]">
        <Sidebar activePanel={activePanel} onPanelToggle={handlePanelToggle} />

        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 flex flex-col overflow-auto">
            <div className="px-8 pt-6">
              <CopilotPanel />
            </div>

            <WorkflowCanvas 
              onEmailTriggerSelect={handleEmailTriggerSelect}
              emailTriggerConfigOpen={emailTriggerConfigOpen}
              onCloseEmailTriggerConfig={() => setEmailTriggerConfigOpen(false)}
              isRunning={isRunning}
            />
          </div>
        </div>

        <RightPanel activePanel={activePanel} onClose={() => setActivePanel(null)} />
      </div>

      <TestRunResultsPanel
        isOpen={testRunResultsOpen}
        onClose={() => setTestRunResultsOpen(false)}
        onRunAgain={handleRunAgain}
      />

      <PublishModal
        isOpen={publishModalOpen}
        onClose={() => setPublishModalOpen(false)}
        onPublish={handlePublish}
        onNavigateToHome={handleNavigateToHome}
      />
    </div>
  );
}