import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Bell, 
  Settings, 
  Search, 
  Download,
  ChevronDown,
  X,
  CheckCircle,
  AlertTriangle,
  XCircle,
  ChevronLeft,
  ChevronRight,
  Calendar,
  User,
  MapPin,
  Activity
} from 'lucide-react';
import { NotificationDropdown } from '../components/NotificationDropdown';
import { UserAccountDropdown } from '../components/UserAccountDropdown';
import { AuditLogDetailPanel } from '../components/AuditLogDetailPanel';

interface AuditLog {
  id: string;
  user: string;
  action: string;
  target: string;
  location: string;
  dateTime: string;
  status: 'success' | 'warning' | 'failed';
  details: string;
  metadata?: {
    ipAddress?: string;
    browser?: string;
    duration?: string;
  };
}

const auditLogs: AuditLog[] = [
  {
    id: '1',
    user: 'Hân Hân',
    action: 'Published',
    target: 'Customer Onboarding Flow',
    location: 'Workflow Builder',
    dateTime: 'Jan 27, 2026, 10:42 AM',
    status: 'success',
    details: 'Published workflow successfully',
    metadata: {
      ipAddress: '192.168.1.42',
      browser: 'Chrome 120',
      duration: '2.3s',
    },
  },
  {
    id: '2',
    user: 'Hân Hân',
    action: 'Logged in',
    target: 'Account',
    location: 'Login Page',
    dateTime: 'Jan 27, 2026, 9:15 AM',
    status: 'success',
    details: 'User signed in with Google',
    metadata: {
      ipAddress: '192.168.1.42',
      browser: 'Chrome 120',
      duration: '1.1s',
    },
  },
  {
    id: '3',
    user: 'Admin',
    action: 'Updated',
    target: 'Invoice Processing Workflow',
    location: 'Workflow Builder',
    dateTime: 'Jan 26, 2026, 4:25 PM',
    status: 'success',
    details: 'Updated webhook configuration',
    metadata: {
      ipAddress: '10.0.0.15',
      browser: 'Firefox 119',
      duration: '3.7s',
    },
  },
  {
    id: '4',
    user: 'Finance Team',
    action: 'Viewed',
    target: 'Audit Log',
    location: 'Audit Log',
    dateTime: 'Jan 26, 2026, 3:10 PM',
    status: 'success',
    details: 'Opened audit history page',
    metadata: {
      ipAddress: '10.0.0.28',
      browser: 'Safari 17',
      duration: '0.8s',
    },
  },
  {
    id: '5',
    user: 'HR Team',
    action: 'Deleted',
    target: 'Old Approval Workflow',
    location: 'Home Dashboard',
    dateTime: 'Jan 25, 2026, 11:03 AM',
    status: 'warning',
    details: 'Workflow removed from system',
    metadata: {
      ipAddress: '10.0.0.34',
      browser: 'Chrome 120',
      duration: '1.5s',
    },
  },
  {
    id: '6',
    user: 'Admin',
    action: 'Created',
    target: 'Email Campaign Trigger',
    location: 'Workflow Builder',
    dateTime: 'Jan 25, 2026, 9:22 AM',
    status: 'success',
    details: 'Created new workflow from template',
    metadata: {
      ipAddress: '10.0.0.15',
      browser: 'Firefox 119',
      duration: '2.1s',
    },
  },
  {
    id: '7',
    user: 'Hân Hân',
    action: 'Tested',
    target: 'Data Sync Automation',
    location: 'Workflow Builder',
    dateTime: 'Jan 24, 2026, 5:18 PM',
    status: 'success',
    details: 'Test run completed successfully',
    metadata: {
      ipAddress: '192.168.1.42',
      browser: 'Chrome 120',
      duration: '4.2s',
    },
  },
  {
    id: '8',
    user: 'Finance Team',
    action: 'Failed',
    target: 'Invoice Processing',
    location: 'Workflow Builder',
    dateTime: 'Jan 24, 2026, 2:45 PM',
    status: 'failed',
    details: 'Test run failed due to invalid API credentials',
    metadata: {
      ipAddress: '10.0.0.28',
      browser: 'Safari 17',
      duration: '1.2s',
    },
  },
  {
    id: '9',
    user: 'HR Team',
    action: 'Updated',
    target: 'Approval Workflow',
    location: 'Workflow Builder',
    dateTime: 'Jan 24, 2026, 11:30 AM',
    status: 'success',
    details: 'Modified trigger conditions',
    metadata: {
      ipAddress: '10.0.0.34',
      browser: 'Chrome 120',
      duration: '2.8s',
    },
  },
  {
    id: '10',
    user: 'Admin',
    action: 'Logged out',
    target: 'Account',
    location: 'Home Dashboard',
    dateTime: 'Jan 23, 2026, 6:15 PM',
    status: 'success',
    details: 'User logged out successfully',
    metadata: {
      ipAddress: '10.0.0.15',
      browser: 'Firefox 119',
      duration: '0.3s',
    },
  },
];

export default function AuditLogPage() {
  const navigate = useNavigate();
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState('All users');
  const [selectedActionType, setSelectedActionType] = useState('All actions');
  const [selectedLocation, setSelectedLocation] = useState('All locations');
  const [selectedDateRange, setSelectedDateRange] = useState('Last 30 days');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [detailPanelOpen, setDetailPanelOpen] = useState(false);

  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [actionDropdownOpen, setActionDropdownOpen] = useState(false);
  const [locationDropdownOpen, setLocationDropdownOpen] = useState(false);
  const [dateDropdownOpen, setDateDropdownOpen] = useState(false);

  const handleExportLogs = () => {
    // Simulate export
    alert('Audit logs exported successfully!');
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedUser('All users');
    setSelectedActionType('All actions');
    setSelectedLocation('All locations');
    setSelectedDateRange('Last 30 days');
  };

  const handleLogClick = (log: AuditLog) => {
    setSelectedLog(log);
    setDetailPanelOpen(true);
  };

  const handleNavigateToHome = () => {
    navigate('/');
  };

  const handleNavigateToTemplates = () => {
    navigate('/templates');
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'warning':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'failed':
        return 'bg-red-50 text-red-700 border-red-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const itemsPerPage = 8;
  const totalPages = Math.ceil(auditLogs.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentLogs = auditLogs.slice(startIndex, endIndex);

  return (
    <div className="h-screen w-screen overflow-hidden bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Top Navigation */}
      <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
        {/* Left: Logo and Nav */}
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white text-sm font-bold">⚡</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">DemoWebsite</span>
          </div>

          <nav className="flex items-center gap-6">
            <button onClick={handleNavigateToHome} className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Home
            </button>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Workflow Designer
            </a>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Automation
            </a>
            <button onClick={handleNavigateToTemplates} className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Templates
            </button>
            <a href="#" className="text-sm font-medium text-gray-900 border-b-2 border-orange-500 pb-1">
              Audit Log
            </a>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Version History
            </a>
          </nav>
        </div>

        {/* Right: Icons */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <button 
              onClick={() => {
                setNotificationOpen(!notificationOpen);
                setUserMenuOpen(false);
              }}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
            >
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <NotificationDropdown 
              isOpen={notificationOpen} 
              onClose={() => setNotificationOpen(false)} 
            />
          </div>
          
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
          
          <div className="relative">
            <button 
              onClick={() => {
                setUserMenuOpen(!userMenuOpen);
                setNotificationOpen(false);
              }}
              className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center hover:bg-purple-200 transition-colors"
            >
              <span className="text-purple-600 text-xs font-semibold">HH</span>
            </button>
            <UserAccountDropdown 
              isOpen={userMenuOpen} 
              onClose={() => setUserMenuOpen(false)} 
            />
          </div>
        </div>
      </header>

      <div className="h-[calc(100vh-64px)] overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-2xl font-semibold text-gray-900 mb-2">Audit Log</h1>
            <p className="text-sm text-gray-600">
              Track user activity, workflow changes, and system events across the platform.
            </p>
          </div>

          {/* Filter Toolbar */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 mb-4">
              {/* Search Input */}
              <div className="lg:col-span-2 xl:col-span-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search logs by user, workflow, action, or location..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* User Filter */}
              <div className="relative">
                <button
                  onClick={() => {
                    setUserDropdownOpen(!userDropdownOpen);
                    setActionDropdownOpen(false);
                    setLocationDropdownOpen(false);
                    setDateDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{selectedUser}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {userDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {['All users', 'Hân Hân', 'Admin', 'Finance Team', 'HR Team'].map((user) => (
                      <button
                        key={user}
                        onClick={() => {
                          setSelectedUser(user);
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {user}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Type Filter */}
              <div className="relative">
                <button
                  onClick={() => {
                    setActionDropdownOpen(!actionDropdownOpen);
                    setUserDropdownOpen(false);
                    setLocationDropdownOpen(false);
                    setDateDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{selectedActionType}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {actionDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {['All actions', 'Created', 'Updated', 'Deleted', 'Published', 'Tested', 'Logged in', 'Logged out', 'Viewed', 'Failed'].map((action) => (
                      <button
                        key={action}
                        onClick={() => {
                          setSelectedActionType(action);
                          setActionDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {action}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Location Filter */}
              <div className="relative">
                <button
                  onClick={() => {
                    setLocationDropdownOpen(!locationDropdownOpen);
                    setUserDropdownOpen(false);
                    setActionDropdownOpen(false);
                    setDateDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{selectedLocation}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {locationDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {['All locations', 'Home Dashboard', 'Workflow Builder', 'Audit Log', 'Templates', 'Login Page'].map((location) => (
                      <button
                        key={location}
                        onClick={() => {
                          setSelectedLocation(location);
                          setLocationDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {location}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Date Range Filter */}
              <div className="relative">
                <button
                  onClick={() => {
                    setDateDropdownOpen(!dateDropdownOpen);
                    setUserDropdownOpen(false);
                    setActionDropdownOpen(false);
                    setLocationDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-700">{selectedDateRange}</span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {dateDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {['Today', 'Last 7 days', 'Last 30 days', 'Custom range'].map((range) => (
                      <button
                        key={range}
                        onClick={() => {
                          setSelectedDateRange(range);
                          setDateDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {range}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleExportLogs}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors"
                >
                  <Download className="w-4 h-4" />
                  Export Logs
                </button>
                <button
                  onClick={handleResetFilters}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg text-sm font-medium transition-colors"
                >
                  <X className="w-4 h-4" />
                  Reset
                </button>
              </div>
            </div>
          </div>

          {/* Audit Log Table */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Action
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Target
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Location
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Date & Time
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                      Details
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {currentLogs.map((log) => (
                    <tr 
                      key={log.id} 
                      onClick={() => handleLogClick(log)}
                      className="hover:bg-gray-50 cursor-pointer transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                            <span className="text-purple-600 text-xs font-semibold">
                              {log.user.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <span className="text-sm font-medium text-gray-900">{log.user}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-700">{log.action}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-900">{log.target}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-600">{log.location}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-600">{log.dateTime}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusBadge(log.status)}`}>
                          {getStatusIcon(log.status)}
                          <span className="capitalize">{log.status}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-600">{log.details}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Showing {startIndex + 1} to {Math.min(endIndex, auditLogs.length)} of {auditLogs.length} logs
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`px-3 py-1.5 border rounded-lg text-sm font-medium transition-colors ${
                      currentPage === page
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detail Panel */}
      <AuditLogDetailPanel
        isOpen={detailPanelOpen}
        log={selectedLog}
        onClose={() => setDetailPanelOpen(false)}
      />
    </div>
  );
}