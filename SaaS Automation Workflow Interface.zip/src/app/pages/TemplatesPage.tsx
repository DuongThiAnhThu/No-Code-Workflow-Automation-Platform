import { useState } from 'react';
import { useNavigate } from 'react-router';
import { 
  Bell, 
  Settings, 
  Search,
  ChevronDown,
  Mail,
  Webhook,
  Database,
  MessageSquare,
  CheckCircle,
  FileText,
  Zap,
  Plus
} from 'lucide-react';
import { NotificationDropdown } from '../components/NotificationDropdown';
import { UserAccountDropdown } from '../components/UserAccountDropdown';
import { TemplatePreviewModal } from '../components/TemplatePreviewModal';

interface Template {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string;
  trigger: string;
  action: string;
  popularity: number;
  dateAdded: string;
}

const templates: Template[] = [
  {
    id: '1',
    title: 'New Email → Send Notification',
    description: 'Trigger when a new email arrives and notify a team channel.',
    category: 'Email automation',
    icon: 'mail',
    trigger: 'Email Received',
    action: 'Send Notification',
    popularity: 98,
    dateAdded: '2026-01-20',
  },
  {
    id: '2',
    title: 'Webhook → Call API',
    description: 'Receive webhook data and send it to another system via API.',
    category: 'Webhook automation',
    icon: 'webhook',
    trigger: 'Webhook',
    action: 'Call API',
    popularity: 95,
    dateAdded: '2026-01-18',
  },
  {
    id: '3',
    title: 'Form Submission → Send Email',
    description: 'When a form is submitted, send a confirmation email automatically.',
    category: 'Email automation',
    icon: 'file',
    trigger: 'Form Submitted',
    action: 'Send Email',
    popularity: 92,
    dateAdded: '2026-01-15',
  },
  {
    id: '4',
    title: 'API Event → Create Workflow Record',
    description: 'Trigger automation when an API request is received.',
    category: 'API integration',
    icon: 'database',
    trigger: 'API Event',
    action: 'Create Record',
    popularity: 89,
    dateAdded: '2026-01-12',
  },
  {
    id: '5',
    title: 'Webhook → Data Sync',
    description: 'Sync webhook payload data into another service.',
    category: 'Data sync',
    icon: 'webhook',
    trigger: 'Webhook',
    action: 'Sync Data',
    popularity: 87,
    dateAdded: '2026-01-10',
  },
  {
    id: '6',
    title: 'Approval Request → Send Notification',
    description: 'When an approval is needed, notify the approver automatically.',
    category: 'Approval workflows',
    icon: 'check',
    trigger: 'Approval Requested',
    action: 'Send Notification',
    popularity: 85,
    dateAdded: '2026-01-08',
  },
  {
    id: '7',
    title: 'New Customer → Welcome Email',
    description: 'Send a welcome email sequence when a new customer signs up.',
    category: 'Email automation',
    icon: 'mail',
    trigger: 'Customer Created',
    action: 'Send Email Sequence',
    popularity: 83,
    dateAdded: '2026-01-05',
  },
  {
    id: '8',
    title: 'Scheduled Report → Send Email',
    description: 'Generate and email reports on a scheduled basis.',
    category: 'Email automation',
    icon: 'file',
    trigger: 'Schedule',
    action: 'Generate & Send Report',
    popularity: 80,
    dateAdded: '2026-01-03',
  },
  {
    id: '9',
    title: 'API Error → Alert Team',
    description: 'Monitor API errors and alert the technical team immediately.',
    category: 'Notifications',
    icon: 'message',
    trigger: 'API Error',
    action: 'Send Alert',
    popularity: 78,
    dateAdded: '2026-01-01',
  },
];

export default function TemplatesPage() {
  const navigate = useNavigate();
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All templates');
  const [selectedSort, setSelectedSort] = useState('Most popular');
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const [sortDropdownOpen, setSortDropdownOpen] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState<Template | null>(null);
  const [previewModalOpen, setPreviewModalOpen] = useState(false);

  const handleNavigateToHome = () => {
    navigate('/');
  };

  const handleNavigateToAuditLog = () => {
    navigate('/audit-log');
  };

  const handleUseTemplate = (template: Template) => {
    // Store template data in localStorage for the builder to load
    localStorage.setItem('templateData', JSON.stringify({
      templateId: template.id,
      templateTitle: template.title,
      trigger: template.trigger,
      action: template.action,
    }));
    navigate('/builder');
  };

  const handlePreviewTemplate = (template: Template) => {
    setPreviewTemplate(template);
    setPreviewModalOpen(true);
  };

  const getIconComponent = (iconType: string) => {
    switch (iconType) {
      case 'mail':
        return <Mail className="w-6 h-6" />;
      case 'webhook':
        return <Webhook className="w-6 h-6" />;
      case 'database':
        return <Database className="w-6 h-6" />;
      case 'message':
        return <MessageSquare className="w-6 h-6" />;
      case 'check':
        return <CheckCircle className="w-6 h-6" />;
      case 'file':
        return <FileText className="w-6 h-6" />;
      default:
        return <Zap className="w-6 h-6" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Email automation':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Webhook automation':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'API integration':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'Data sync':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'Notifications':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'Approval workflows':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <div className="h-screen w-screen overflow-hidden bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Top Navigation */}
      <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6">
        {/* Left: Logo and Nav */}
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-pink-500 rounded-lg flex items-center justify-center">
              <span className="text-white text-sm font-bold">⚡</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">DemoWebsite</span>
          </div>

          <nav className="flex items-center gap-6">
            <button onClick={handleNavigateToHome} className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Home
            </button>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Workflow Designer
            </a>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Automation
            </a>
            <a href="#" className="text-sm font-medium text-gray-900 border-b-2 border-orange-500 pb-1">
              Templates
            </a>
            <button onClick={handleNavigateToAuditLog} className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Audit Log
            </button>
            <a href="#" className="text-sm text-gray-600 hover:text-gray-900 transition-colors">
              Version History
            </a>
          </nav>
        </div>

        {/* Right: Icons */}
        <div className="flex items-center gap-4">
          <div className="relative">
            <button 
              onClick={() => {
                setNotificationOpen(!notificationOpen);
                setUserMenuOpen(false);
              }}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative"
            >
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <NotificationDropdown 
              isOpen={notificationOpen} 
              onClose={() => setNotificationOpen(false)} 
            />
          </div>
          
          <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
          
          <div className="relative">
            <button 
              onClick={() => {
                setUserMenuOpen(!userMenuOpen);
                setNotificationOpen(false);
              }}
              className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center hover:bg-purple-200 transition-colors"
            >
              <span className="text-purple-600 text-xs font-semibold">HH</span>
            </button>
            <UserAccountDropdown 
              isOpen={userMenuOpen} 
              onClose={() => setUserMenuOpen(false)} 
            />
          </div>
        </div>
      </header>

      <div className="h-[calc(100vh-64px)] overflow-y-auto">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-2xl font-semibold text-gray-900 mb-2">Templates</h1>
            <p className="text-sm text-gray-600">
              Start faster by using pre-built automation templates.
            </p>
          </div>

          {/* Toolbar */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-4">
              {/* Search Bar */}
              <div className="lg:col-span-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search templates..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Category Filter */}
              <div className="relative">
                <button
                  onClick={() => {
                    setCategoryDropdownOpen(!categoryDropdownOpen);
                    setSortDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <span className="text-gray-700">{selectedCategory}</span>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {categoryDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {[
                      'All templates',
                      'Email automation',
                      'API integration',
                      'Webhook automation',
                      'Data sync',
                      'Notifications',
                      'Approval workflows',
                    ].map((category) => (
                      <button
                        key={category}
                        onClick={() => {
                          setSelectedCategory(category);
                          setCategoryDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Sort Dropdown */}
              <div className="relative">
                <button
                  onClick={() => {
                    setSortDropdownOpen(!sortDropdownOpen);
                    setCategoryDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between px-4 py-2.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 transition-colors"
                >
                  <span className="text-gray-700">{selectedSort}</span>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>
                {sortDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
                    {['Most popular', 'Recently added', 'Recommended'].map((sort) => (
                      <button
                        key={sort}
                        onClick={() => {
                          setSelectedSort(sort);
                          setSortDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2.5 text-sm hover:bg-gray-50 transition-colors"
                      >
                        {sort}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Create Template Button */}
              <div>
                <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-lg text-sm font-medium transition-colors">
                  <Plus className="w-4 h-4" />
                  Create Template
                </button>
              </div>
            </div>
          </div>

          {/* Template Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <div
                key={template.id}
                className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
              >
                <div className="p-6">
                  {/* Top Section */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-pink-500 rounded-lg flex items-center justify-center text-white">
                      {getIconComponent(template.icon)}
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getCategoryColor(template.category)}`}>
                      {template.category}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-semibold text-gray-900 mb-2">
                    {template.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-gray-600 mb-6 line-clamp-2">
                    {template.description}
                  </p>

                  {/* Actions */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleUseTemplate(template)}
                      className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors"
                    >
                      Use Template
                    </button>
                    <button
                      onClick={() => handlePreviewTemplate(template)}
                      className="px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg text-sm font-medium transition-colors"
                    >
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      <TemplatePreviewModal
        isOpen={previewModalOpen}
        template={previewTemplate}
        onClose={() => setPreviewModalOpen(false)}
        onUseTemplate={handleUseTemplate}
      />
    </div>
  );
}
